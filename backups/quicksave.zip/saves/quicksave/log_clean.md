

*The adventure begins...*